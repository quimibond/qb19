def hi():\n    return 1
