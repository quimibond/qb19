# qbexfil helper module
VERSION = "1.1.0"
